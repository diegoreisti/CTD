package entities;

public interface IVoam {

    void voar();
}
