package entities;

public interface IAtacarDefender {

    public void atacar();

    public void defender();
}
