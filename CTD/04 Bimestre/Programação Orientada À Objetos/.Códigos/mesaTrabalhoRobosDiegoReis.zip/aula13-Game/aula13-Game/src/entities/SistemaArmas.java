package entities;

public abstract class SistemaArmas {
    protected int energia;

    public abstract void mostrar();
}
