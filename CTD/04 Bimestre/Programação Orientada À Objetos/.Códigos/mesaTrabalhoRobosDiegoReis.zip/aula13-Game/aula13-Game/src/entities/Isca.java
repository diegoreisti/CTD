package entities;

public class Isca extends SistemaArmas{
    @Override
    public void mostrar() {

        System.out.println("Mostrar isca");
    }
}
