package entities;

public interface IProduto {
    int getId();
    String getNome();
    double retornaPreco();
}


/*
EQUIPE 4
Diego Reis
Murillo Paulino Zuffo
Sankler Bergman
Rodrigo Gottschall Criscuolo
Allan Miranda
Camila Ferreira Tinelli
*/