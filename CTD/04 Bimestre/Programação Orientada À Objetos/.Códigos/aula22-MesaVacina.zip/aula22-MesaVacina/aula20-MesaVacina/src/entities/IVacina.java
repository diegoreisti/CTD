package entities;

public interface IVacina {

    String aplicarVacina();

}
