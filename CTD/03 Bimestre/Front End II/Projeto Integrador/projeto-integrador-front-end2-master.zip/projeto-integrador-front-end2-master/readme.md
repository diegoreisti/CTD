# Projeto Integrador

Este projeto integrador do curso Certified Tech Developer (CTD) da Digital House, da matéria de Front End 2.

O projeto consiste em um pequeno aplicativo de gerenciamento de tarefas, dentro do qual podemos realizar algumas tarefas do TODO.


## Autores
- [Diego Reis](https://github.com/diegoreisti)
- [Izabella Leite](https://github.com/izaleite)
- [Alcilene Reis](https://github.com/alcilene)
- [Ewerton L. Pereira](https://github.com/ewertonlp)
- [Clayton Alexandre Barbosa Pereira](https://github.com/claytonmaxx)

## Funcionalidades

- Ver tarefas pendentes.
- Ver tarefas terminadas.
- Marcar uma tarefa como terminada.
- Criar tarefas novas.
- Visualizar a data de criação de uma tarefa.
