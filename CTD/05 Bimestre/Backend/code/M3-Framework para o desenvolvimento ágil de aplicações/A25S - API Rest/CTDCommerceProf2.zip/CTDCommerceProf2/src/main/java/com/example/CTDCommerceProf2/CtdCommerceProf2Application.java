package com.example.CTDCommerceProf2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CtdCommerceProf2Application {

	public static void main(String[] args) {
		SpringApplication.run(CtdCommerceProf2Application.class, args);
	}

}
