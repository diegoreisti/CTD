public class Triangulo {

    private String cor;
    private int tamanho;

    public Triangulo(String cor) {
        this.cor = cor;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public int getTamanho() {
        return tamanho;
    }

    public String getCor() {
        return cor;
    }
}
