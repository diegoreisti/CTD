public class FlyweightTriangulo {
}
