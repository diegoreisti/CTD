import java.util.HashMap;
import java.util.Map;

public class FlyweightQuadrado {

    private Map<String, Triangulo> trianguloMap;
}
