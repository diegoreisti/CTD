package com.api.parkingcontroll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkingControllApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingControllApplication.class, args);
	}

}
