package com.api.parkingcontroll;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingControllApplicationTests {

	@Test
	void contextLoads() {
	}

}
